# Discrepancies

Automated acceptance: PASS.

Record reproducible implementation differences, bugs, specification ambiguities, environment limitations, and provenance questions here.
